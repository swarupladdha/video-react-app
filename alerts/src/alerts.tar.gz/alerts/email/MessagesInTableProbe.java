package alerts.email;

import java.io.FileInputStream;

import java.sql.ResultSet;
import java.sql.Blob;

import java.util.List;
import java.util.Set;
import java.util.Iterator;
import java.util.Properties;
import java.util.HashMap;

import javax.activation.DataHandler;
import javax.mail.Session;
import javax.mail.Message;
import javax.mail.Transport;
import javax.mail.Multipart;

import javax.mail.util.ByteArrayDataSource;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMultipart;

import org.w3c.dom.Node;

import org.apache.log4j.Logger;

import alerts.sms.SMSProvider;
import alerts.sms.SMSProviderFactory;
import alerts.utils.Constants;
import alerts.utils.TargetUser;

/** The thread or probe that looks for messages in the messagesintable
 *  and sends the message via email or sms based on the messageType.
 *  Once the message is sent, if it is an sms, it is stored in the
 *  messages_sent_table along with the responseId.  Later on the 
 *  MessagesSentTableProbe probes the messages_sent_table and comes
 *  up with the status of the message.  The messages are deleted from
 *  the messagesintable by this thread.
 *  @author Sushma P
 *  @date July-19-2010
 *  @version 1.0
 */

public class MessagesInTableProbe implements Runnable {

    private int id = 0;
    private HashMap defaultProviderParameters ;    
    static final Logger logger = Logger.getLogger(MessagesInTableProbe.class);

    public MessagesInTableProbe(int id) {
        this.id = id; 
    }

    public void run() {
        
        VinrMessagesInTable mesgInTable = new VinrMessagesInTable();
        int msgid=-1 ;
        //VinrMessagesSentTable messagesSentTable = new VinrMessagesSentTable();
        while (true) {
            try {
            	Thread.sleep( 1000 ) ;
                mesgInTable.setConnection();
                //messagesSentTable.setConnection();
                ResultSet rs1 = mesgInTable.readNewMessages(this.id);
                //messagesSentTable.setConnection(mesgInTable.getConnection());
                 while (rs1.next()) {
                     String sms_response = null;
                     String email = null;
                     boolean is_Insert_Success = false;

                     msgid = rs1.getInt(1);
                     int msgtype = rs1.getInt(2);
                     String address = rs1.getString(3);
                     String message = rs1.getString(4);
				     String versionColumn = rs1.getString(5);	
				     String provider = rs1.getString(6);	
				     Blob blobContent = rs1.getBlob(7);	
                     String date = rs1.getString(8);
                     String customData = rs1.getString(9);
                     String msgIdString = "" + msgid;
                     boolean bodyType ;
              
				     String xmlMessage = new StringBuffer("<message>").append(rs1.getString(3)).append(rs1.getString(4)).append(rs1.getString(5)).append(rs1.getString(6)).append("</message>").toString();
				     logger.debug("The value of XMLMessage in MessagesInTableProbe is ::::::---> "+ xmlMessage);	
		   	        
       
                     VinrMessageParser parser = new VinrMessageParser();
                     parser.parse(xmlMessage);	

                     String sender = parser.getFromList();
                     List<TargetUser> recipients = parser.getToList();
                     String cc = parser.getCCList();
                     String subject = parser.getSubject();
		     logger.debug("The value of subject in MessagesInTableProbe   --------> " + subject);	
                     String body = parser.getBody();
		     logger.debug("The value of body in MessagesInTableProbe   ::::::::::=>  " + body);
                     String attachmentName = parser.getAttachmentName();		     
		     String version = parser.getVersion();
		     logger.debug("The value of version in MessagesInTableProbe is ===========> " + version);	
		     String senderId = parser.getSenderId();	
		     String numbersList = parser.getMobileList();
                     String textMessage = parser.getShortText();	
		     logger.debug("The value of textMessage in MessagesInTableProbe is +++++++++++=>  " + textMessage);	
		     		
                     String primaryProvider = parser.getPrimaryProviderCode();  
		     System.out.println("In MessagesinTableProbe :::: The value of PrimaryProviderCode is =====>  " + primaryProvider);	
		     logger.debug("In MessagesinTableProbe :::: The value of PrimaryProviderCode is =====>  " + primaryProvider);	
		     try {
                         String fileName = System.getenv("DefaultSmsProvider_CONFIG_FILE");      			

            		 Properties p = new Properties(System.getProperties());
            		 FileInputStream propFile = new FileInputStream(fileName);
            		 p.load(propFile);
			 String userName = p.getProperty("user"); 
			 String passwd = p.getProperty("passwd");
			 //String senderId = p.getProperty("sid");
 
			 defaultProviderParameters = new HashMap();
			 System.out.println("The value of SID for default provider is  =========== " + senderId);
			 defaultProviderParameters.put("userid", userName);
			 defaultProviderParameters.put("password", passwd);
			 defaultProviderParameters.put("sid", senderId);            			
        	     } catch(Exception e) {
            	         e.printStackTrace();
        	     }


        	     HashMap primaryProviderParameters = parser.getPrimaryProviderParameters();
        	     
        	     bodyType = parser.getBodyContentType() ;


                     if (msgtype == Constants.EMAIL_CODE) {                         
                    	
                         if (attachmentName == null) {
                             email = VinrEmailDispatcher.sendPersonalPlainMail(subject, body, sender, recipients, cc, msgid, bodyType);
                         } else {
                             email = VinrEmailDispatcher.sendPersonalAttachmentMail(subject, body, sender,recipients,cc, msgid, blobContent, attachmentName, bodyType);
                         }
                         if (email.equalsIgnoreCase(Constants.SUCCESS_STRING)) {
                             mesgInTable.deleteMessage(msgid);
                             //is_Insert_Success = messagesSentTable.insertDataIntoTable(msgid, msgtype, sms_response, address, message, provider, date, customData);    
                         }
                         if (email.equalsIgnoreCase( Constants.ERROR_STRING ) ) {
                        	 mesgInTable.touchMessage(msgid, 300) ;
                         }
                     }

                     if (msgtype == Constants.SMS_CODE) {

                         SMSProviderFactory factory = new SMSProviderFactory();
                         SMSProvider smsProvider = null;
 
			 if((version != null) && !(version.equals(""))) {
			     smsProvider = SMSProviderFactory.getSMSProviderInstance(primaryProvider);
                             logger.debug("The value of txtMsg before passing to sendSMSroutine is  ----> " + textMessage);	
                             sms_response = smsProvider.sendSMS(primaryProviderParameters, msgIdString, recipients, textMessage); //gets the response back from the call to sendSMS()
			 	} else {
//                             String defaultLowProvider = Constants.DEFAULT_SMS_PROVIDER;
                             SMSProvider defaultHighProvider = SMSProviderFactory.getSMSProviderInstance(new String ("unicel")) ;
                             //smsProvider = SMSProviderFactory.getSMSProviderInstance(defaultHighProvider);
                             HashMap defaultUnicelProviderParameters = new HashMap();
                			 defaultUnicelProviderParameters.put("userid", "RaosIn");
                			 defaultUnicelProviderParameters.put("password", "56R2Q");
                			 defaultUnicelProviderParameters.put("sid", "groupz");            			
                             
                             sms_response = defaultHighProvider.sendSMS(defaultUnicelProviderParameters, msgIdString, recipients, textMessage);				
                         }

                         if (sms_response.equalsIgnoreCase(Constants.SUCCESS_STRING)) {
                             mesgInTable.deleteMessage(msgid);
                             //is_Insert_Success = messagesSentTable.insertDataIntoTable(msgid, msgtype, sms_response, address, message, provider, date, customData);
                         }
                         if (sms_response.equalsIgnoreCase( Constants.ERROR_STRING ) ) {
                        	 mesgInTable.touchMessage(msgid, 300) ;
                         }
                     }
                     
                     if (msgtype == Constants.EMAIL_AND_SMS_CODE) {

                         SMSProviderFactory factory = new SMSProviderFactory();
                         SMSProvider smsProvider = null;

                         if (attachmentName == null) {
                             email = VinrEmailDispatcher.sendPersonalPlainMail(subject, body, sender, recipients, cc, msgid, bodyType);
                         } else {
                             email = VinrEmailDispatcher.sendPersonalAttachmentMail(subject, body, sender,recipients,cc, msgid, blobContent, attachmentName, bodyType);                              
                         }        
                         if (email.equalsIgnoreCase( Constants.ERROR_STRING ) ) {
                        	 mesgInTable.touchMessage(msgid, 300) ;
                         }

			 
                         if((version != null) && !(version.equals(""))) {
                             smsProvider = factory.getSMSProviderInstance(primaryProvider);                                                              
                             sms_response = smsProvider.sendSMS(primaryProviderParameters, msgIdString, recipients, textMessage);
                         } else {
                             String defaultProvider = Constants.DEFAULT_SMS_PROVIDER;

                             smsProvider = factory.getSMSProviderInstance(defaultProvider);
                             sms_response = smsProvider.sendSMS(defaultProviderParameters, msgIdString, recipients, textMessage);
                         }
                         if (sms_response.equalsIgnoreCase( Constants.ERROR_STRING ) ) {
                        	 mesgInTable.touchMessage(msgid, 300) ;
                         }

                         if ((sms_response.equalsIgnoreCase(Constants.SUCCESS_STRING)) || (email.equalsIgnoreCase(Constants.SUCCESS_STRING) && sms_response.equalsIgnoreCase(Constants.SUCCESS_STRING))) {
                             mesgInTable.deleteMessage(msgid);
                             //is_Insert_Success = messagesSentTable.insertDataIntoTable(msgid, msgtype, sms_response, address, message, provider, date, customData);
                         }
                         //mesgInTable.deleteMessage(msgid);
                     }                      

                     // once the message has been sent through the primary or the default provider, then add the information
                     // to the messages_sent_table
		     logger.debug("The value of messageId in MessagesintableProbe is ==> ::: " + msgid);
		     logger.debug("The value of messageType in MessagesintableProbe is ==> ::: " + msgtype);	
		     logger.debug("The value of sms_response in MessagesintableProbe is ==> ::: " + sms_response);
		     logger.debug("The value of address in MessagesintableProbe is ==> ::: " + address);
		     logger.debug("The value of message in MessagesintableProbe is ==> ::: " + message);
		     logger.debug("The value of provider in MessagesintableProbe is ==> ::: " + provider);
		     logger.debug("The value of date in MessagesintableProbe is ==> ::: " + date );
		     logger.debug("The value of customData in  MessagesintableProbe is ==> ::: " + customData);
                     //boolean is_Insert_Success = messagesSentTable.insertDataIntoTable(msgid, msgtype, sms_response, address, message, provider, date, customData);

                     // after the insertion of the message into the messages_sent_table, remove it from the messagesInTable
                     // mesgInTable.deleteMessage(msgid) ; 

                 }//end of while
                 rs1.close();
             } catch(Exception e) {     
            	 logger.error("Excepton Caught in MessagesinTableProbe Class") ;
            	 logger.error(e.getMessage()) ;
                 e.printStackTrace();     
                 mesgInTable.touchMessage(msgid, 3600) ;
                 mesgInTable.releaseConnection();
                 //messagesSentTable.releaseConnection();
                 //System.exit(0) ;
             } finally {
                 mesgInTable.releaseConnection();
                 //messagesSentTable.releaseConnection();
             }
             
             Thread.yield();
        } 
    } 
}
