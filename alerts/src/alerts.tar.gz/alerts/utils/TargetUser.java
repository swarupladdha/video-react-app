package alerts.utils;

public class TargetUser {

		String name ;
		String mobileNumber ;
		String prefix ;
		String emailId ;
		String value1 ;
		
		
		public boolean personalizeEmail( String mesgBody ) {
			if (mesgBody == null || mesgBody.trim().isEmpty() == true) {
				return false ;
			}
		
			mesgBody = mesgBody.replaceAll("$name", name) ;
			mesgBody = mesgBody.replaceAll("$number", mobileNumber) ;
			mesgBody = mesgBody.replaceAll("$prefix", prefix) ;
			mesgBody = mesgBody.replaceAll("emailId", emailId) ;
			return false ;
		}
		
		public String getName( ) {
			return name ;
		}
		
		public void setName( String name ) {
			this.name = name ;
		}
		
		public String getMobileNumber() {
			return mobileNumber ;
		}
		
		public void setMobileNumber( String mobNumber ) {
			this.mobileNumber = mobNumber ;
		}
		
		public String getPrefix( ) {
			return this.prefix ;
		}
		
		public void setPrefix( String title ) {
			this.prefix = title ;
		}
		
		public String getEmailID() {
			return this.emailId ;
		}
		
		public void setEmailID( String emailid ) {
			this.emailId = emailid ;
		}
		
		public void setValue1( String val) {
			this.value1 = val ;
		}

		public String getValue1() {
			return this.value1 ;
		}
		
}
