package alerts.sms;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.sql.ResultSet;
import java.util.HashMap;
import alerts.utils.TargetUser;

import org.w3c.dom.Node;

import org.apache.log4j.Logger;

import java.util.Iterator;
import java.util.List;
import java.util.Set;

import alerts.email.VinrMessagesSentTable;
import alerts.email.VinrMessagesInTable;
import alerts.email.VinrMessageParser;
import alerts.utils.Constants;


/** This class contains the sendSMS() implementation for 
 *  for SmsCountry
 *
 *  @author Sushma
 *  @date July-08-2010
 *  @version 1.0
 */

public class VinrSMSCountry implements SMSProvider {
    static final Logger logger = Logger.getLogger(VinrSMSCountry.class);
    public String sendSMS(HashMap providerParams, String msgId, List<TargetUser> numbersList, String textMessage) { 
	System.out.println("The length of hashmap in VinrSMSCountry is  _______ " + providerParams.size());

        try {
	    String userId = (String) providerParams.get("userid");
	    String password = (String) providerParams.get("password");
	    String senderId = (String) providerParams.get("sid"); 

            logger.debug("The value of userId in VinrSMSCountry is :::::::::::::::::::::::: "  +userId);
 
	    logger.debug("the value of password in VinrSMSCountry is ******************** "  +password );
	    logger.debug("The value of senderId in VinrSMSCountry is +++++++++++++++++++  "  +senderId);
	    logger.debug("The value of message in VinrSMSCountry is +*+*+*+*+*+*  " + textMessage);
            String singleSmsToSend = new StringBuffer("<smscountry><sendMsg>").
                                               append("<user>").append(userId).append("</user>").
                                               append("<passwd>").append(password).append("</passwd>").
                                               append("<to>").append( numbersList).append("</to>").
                                               append("<sid>").append(senderId).append("</sid>").
                                               append("<text>").append(textMessage).append("</text>").
                                               append("<DR>Y</DR><MTYPE>N</MTYPE></sendMsg></smscountry>").toString();

                
            String response = "";
	    URL url = new URL("http://www.smscountry.com/SaveXMLJobData.asp");
            URLConnection conn = url.openConnection();
            conn.setDoOutput(true);
                        
            String XML_DATA = "XML_DATA="+URLEncoder.encode(singleSmsToSend, "UTF-8");
	    //  String XML_DATA = "XML_DATA="+URLEncoder.encode(singleSmsToSend);
            //System.out.println("XML PRINTING :"+XML_DATA);
            OutputStreamWriter out = new OutputStreamWriter(conn.getOutputStream());
            out.write(XML_DATA);
            out.close();

            BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            String inputLine;
            while ((inputLine = in.readLine()) != null)
                response += inputLine;

            logger.debug("The value of responseId in VinrSMSCountry CLASS IS ----========------> " + response);                
	    in.close();         
            //System.out.println("The list of Mobile Nos are :" +toList);
            //System.out.println("response of sendSms routine is : " + response);                     
  	    //return response;                               								

	    return Constants.SUCCESS_STRING;			
        } catch(Exception e) {
            e.printStackTrace();
            return Constants.ERROR_STRING;
        } 
        //return Constants.SUCCESS_STRING;     
    } 
}                  
