INSERT INTO MessagesInTable( MsgType, Address, Message, Attachment, Time, Date) VALUES(1,'<tolist><to><name>Suthindran</name><number>+91.9880839078</number></to></tolist>', '<sid>vinr</sid><shorttext>testing from code... xyz...</shorttext>', null, CURRENT_TIME, sysdate() ) ;




INSERT INTO MessagesInTable( MsgType, Address, Message, Attachment, Time, Date) VALUES(1,'<pcode>RAOS</pcode><acode>RAOS</acode><tolist><to><name>Suthindran</name><number>+91.9880839078</number></to></tolist><pin>rao14</pin><signature>groupz</signature>', '<shorttext>"&#039;" testing "&quot;" from "&gt;" alternateSms "&quot;" routine</shorttext> &amp;', null, CURRENT_TIME, sysdate() ) ;


INSERT INTO MessagesInTable( MsgType, Address, Message, Attachment, Time, Date) VALUES(1,'<tolist><to><name>Sushma</name><number>+91.9880839078</number></to></tolist>', '<shorttext>testing from alternateSms routine</shorttext>', null, CURRENT_TIME, sysdate() ) ;


