INSERT INTO MessagesInTable( MsgType, Address, Message, Attachment, Time, Date) VALUES(2,'<tolist><to><name>Sushma</name><email>sushma.rameshb@gmail.com</email></to><to><name>One More</name><email>sushma.katragunta@gmail.com</email></to></tolist><cclist><cc><name>Sushma Ramesh</name><email>suthi@joviandata.com</email></cc></cclist><from><name>VInR</name><email>no-reply@beta.vinr.in</email></from>', '<subject>testing new xml format</subject><body>this is the content for testing new xml which definted attachment as well</body>', 'tomcat.gif', CURRENT_TIME, sysdate() ) ;


