INSERT INTO MessagesInTable( MsgType, Address, Message, Attachment, Time, Date) VALUES(2, '<tolist><to><name>Sushma Ramesh</name><email>sushma.rameshb@gmail.com</email><number>+91.9886209171</number></to><to><name>Ramesh Babu P</name><email>rameshbabup@gmail.com</email><number>+91.9986772623</number></to></tolist><cclist><cc><name>Sushma Katragunta</name><email>sushma.katragunta@gmail.com</email><number>+91.9449628968</number></cc></cclist><from><name>VInR</name><email>no-reply@beta.vinr.in</email></from>','<sid>vinr</sid><shorttext>testing by sushma...</shorttext><subject>test by sushma</subject><body>this is the content for testing new xml which definted attachment as well</body>', null, CURRENT_TIME, sysdate() ) ;


INSERT INTO MessagesInTable( MsgType, Address, Message, Attachment, Time, Date) VALUES(2, '<tolist><to><name>Suthindran</name><email>suthindran.rao@infosoftjoin.in</email><number>+91.9880839078</number></to><to><name>Sushma Pathipati</name><email>sushma.rameshb@gmail.com</email><number>+91.9886209171</number></to></tolist><from><name>Sushma Pathipati</name><email>sushma.rameshb@gmail.com</email></from>',' <subject>test email and sms</subject><body>email 3</body><shorttext>sms 3</shorttext>', null, CURRENT_TIME, sysdate() );


INSERT INTO MessagesInTable( MsgType, Address, Message, Attachment, Time, Date) VALUES(2, '<tolist><to><name>Suthindran</name><email>suthindran.rao@infosoftjoin.in</email><number>+91.9880839078</number></to><to><name>Sushma Pathipati</name><email>sushma.rameshb@gmail.com</email><number>+91.9886209171</number></to></tolist><from><name>Sushma Pathipati</name><number>+91.9886209171</number></from>',' <subject>test email and sms</subject><body>email 3</body><shorttext>sms 3</shorttext>', null, CURRENT_TIME, sysdate() );


INSERT INTO MessagesInTable( MsgType, Address, Message, Attachment, Time, Date) VALUES(2, '<tolist><to><name>Suthindran</name><email>suthindran.rao@infosoftjoin.in</email><number>+91.9880839078</number></to><to><name>Sushma Pathipati</name><email>sushma.rameshb@gmail.com</email><number>+91.9886209171</number></to></tolist><from><name>Sushma Pathipati</name><number>+91.9886209171</number><email>sushma.rameshb@gmail.com</email></from>',' <subject>test email and sms</subject><body>email 3</body><shorttext>sms 3</shorttext>', null, CURRENT_TIME, sysdate() );


INSERT INTO MessagesInTable( MsgType, Address, Message, Attachment, Time, Date) VALUES(0, '<tolist><to><name>Suthindran</name><email>suthindran.rao@infosoftjoin.in</email></to><to><name>Sushma Pathipati</name><email>sushma.rameshb@gmail.com</email></to></tolist><from><name>Sushma Pathipati</name><email>sushma.rameshb@gmail.com</email></from>',' <subject>test email and sms</subject><body>email 3</body>', null, CURRENT_TIME, sysdate() );



INSERT INTO MessagesInTable( MsgType, Address, Message, Attachment, Time, Date) VALUES(0,'<tolist><to><name>Sushma</name><email>sushma.rameshb@gmail.com</email></to><to><name>One More</name><email>sushma.katragunta@gmail.com</email></to></tolist><from><name>VInR</name><email>no-reply@beta.vinr.in</email></from>', '<subject>testing new xml format</subject><body>this is the content for testing new xml which definted attachment as well</body>', '/home/sushma/Desktop/tomcat.gif', CURRENT_TIME, sysdate() ) ;




INSERT INTO MessagesInTable( MsgType, Address, Message, Attachment, Time, Date) VALUES(2, '<tolist><to><name>Suthindran</name><email>suthindran.rao@infosoftjoin.in</email><number>+91.9880839078</number></to><to><name>Sushma Pathipati</name><email>sushma.rameshb@gmail.com</email><number>+91.9886209171</number></to></tolist><from><name>Sushma Pathipati</name><email>sushma.rameshb@gmail.com</email><number>+91.9886209171</number></from>','<subject>email & sms test </subject><body>email test</body><shorttext>sms test</shorttext>', null, CURRENT_TIME, sysdate() );
