INSERT INTO MessagesInTable( MsgType, Address, Message, Attachment, Time, Date) VALUES(1,'<tolist><to><name>Suthindran</name><number>+91.9880839078</number></to></tolist>', '<sid>vinr</sid><shorttext>testing from code... xyz...</shorttext>', null, CURRENT_TIME, sysdate() ) ;



